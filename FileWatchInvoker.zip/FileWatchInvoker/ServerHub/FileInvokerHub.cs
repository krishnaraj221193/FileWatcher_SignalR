﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FileWatchInvoker
{
    public class FileInvokerHub : Hub
    {
        public async Task SendMessage(string fileName, string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", fileName, message,System.DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));
        }
    }
}
