﻿using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FileWatchInvoker
{
    public class FileWatchHandler
    {
        private HubConnection _connection;

        private readonly IConfiguration _config;
        static string _filePath { get; set; }
        public FileWatchHandler(IConfiguration config)
        {
            _config = config;
            _filePath = _config.GetSection("AppSettings")["FilePath"];
            _connection= new HubConnectionBuilder()
                .WithUrl("http://localhost:49972/ChatHub")
                .Build();
        }
        public void watch()
        {
            FileSystemWatcher watcher = new FileSystemWatcher();
            watcher.Path = _filePath;
            watcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.Size | NotifyFilters.Attributes;
            watcher.Filter = "*.*";
            watcher.Created += OnCreated;
            watcher.Changed += OnChanged;
            watcher.Renamed += OnRenamed;
            watcher.Deleted += OnDeleted;
            watcher.EnableRaisingEvents = true;
            
            _connection.Closed += async (error) =>
            {
                await Task.Delay(new Random().Next(0, 5) * 1000);
                await _connection.StartAsync();
            };
        }
        private void OpenConnection()
        {
            if(_connection.State==HubConnectionState.Disconnected)
            _connection.StartAsync().Wait();
        }
        protected void OnCreated(object sender,FileSystemEventArgs e)
        {
            OpenConnection();
            _connection.InvokeAsync("SendMessage",
                   e.Name, "File Created").Wait();          
        }
        protected void OnChanged(object sender, FileSystemEventArgs e)
        {
            OpenConnection();
            _connection.InvokeAsync("SendMessage",
                   e.Name, "File Changed").Wait();
            
        }
        protected void OnRenamed(object sender, FileSystemEventArgs e)
        {
            OpenConnection();
            _connection.InvokeAsync("SendMessage",
                   e.Name, "File Renamed").Wait();
        }
        protected void OnDeleted(object sender, FileSystemEventArgs e)
        {
            OpenConnection();
            _connection.InvokeAsync("SendMessage",
                   e.Name, "File Deleted").Wait();           
        }
    }
}
