﻿"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").build();

//Disable send button until connection is established
//document.getElementById("sendButton").disabled = true;

connection.on("ReceiveMessage", function (FileName, message,timeInvoked) {
    var msg = message.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    var encodedMsg = "FileName : " + FileName + "<br/> Event Type => " + msg + "<br/> Date : " + timeInvoked;
    var li = document.createElement("li");
    li.innerHTML = encodedMsg;
    document.getElementById("messagesList").appendChild(li);
});
connection.start();
//connection.start().then(function () {
//    document.getElementById("sendButton").disabled = false;
//}).catch(function (err) {
//    return console.error(err.toString());
//});

//document.getElementById("sendButton").addEventListener("click", function (event) {
//    var user = document.getElementById("userInput").value;
//    var message = document.getElementById("messageInput").value;
//    connection.invoke("SendMessage", user, message).catch(function (err) {
//        return console.error(err.toString());
//    });
//    event.preventDefault();
//});
document.getElementById("btnRename").addEventListener("click", function (event) {
    var message = document.getElementById("messageInput").value;

    $.ajax({
        url: "/Home/Rename",
        data: {
            "fileName": message
        },
        success: function () { console.log("File Renamed") },
        dataType: "json"
    });
    event.preventDefault();
});

document.getElementById("btnAppend").addEventListener("click", function (event) {
    var message = document.getElementById("messageInput").value;

    $.ajax({
        url: "/Home/Append",
        data: {
            "message": message
        },
        success: function () { console.log("Message Appended to File") },
        dataType: "json"
    });
    event.preventDefault();
});


document.getElementById("btnCreate").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var message = document.getElementById("messageInput").value;
    
    $.ajax({
        url: "/Home/CreateFile",
        data: {
            "fileName": message
        },
        success: function () { console.log("File Created") },
        dataType: "json"
    });
    event.preventDefault();
});

document.getElementById("btnDelete").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var message = document.getElementById("messageInput").value;

    $.ajax({
        url: "/Home/Delete",
        data: {
            "fileName": message
        },
        success: function () { console.log("File Deleted") },
        dataType: "json"
    });
    event.preventDefault();
});