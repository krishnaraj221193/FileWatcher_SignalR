﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FileWatchInvoker.Common
{
    public class Constants
    {
        public static readonly string SendMessage = "SendMessage";
        public static readonly string RecieveMessage = "ReceiveMessage";
        public static readonly string FileCreated = "File Created";
        public static readonly string FileChanged = "File Changed";
        public static readonly string FileDeleted = "File Deleted";
        public static readonly string FileRenamed = "File Renamed";

    }
}
