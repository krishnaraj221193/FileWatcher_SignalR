﻿using FileWatchInvoker.Common;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FileWatchInvoker
{
    /// <summary>
    /// File Watcher Task Runner for Watching File Event in the Location
    /// </summary>
    public class FileWatchHandler
    {
        private HubConnection _connection;

        private readonly IConfiguration _config;
        static string _filePath { get; set; }
       
        public FileWatchHandler(IConfiguration config)
        {
            _config = config;
            _filePath = _config.GetSection("AppSettings")["FilePath"];
            _connection = new HubConnectionBuilder()
                .WithUrl(_config.GetSection("AppSettings")["SignalRUrl"])
                .Build();
        }
        /// <summary>
        /// Folder Watcher of particular Directory
        /// </summary>
        public void folderWatcher()
        {
            FileSystemWatcher watcher = new FileSystemWatcher();
            watcher.Path = _filePath;
            watcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.Size | NotifyFilters.Attributes;
            watcher.Filter = "*.*";
            watcher.Created += OnCreated;
            watcher.Changed += OnChanged;
            watcher.Renamed += OnRenamed;
            watcher.Deleted += OnDeleted;
            watcher.EnableRaisingEvents = true;
            
            _connection.Closed += async (error) =>
            {
                await Task.Delay(new Random().Next(0, 5) * 1000);
                await _connection.StartAsync();
            };
        }
        /// <summary>
        /// Create or Open the SignalR Connection for Event Notification
        /// </summary>
        private void OpenConnection()
        {
            if(_connection.State==HubConnectionState.Disconnected)
            _connection.StartAsync().Wait();
        }
        /// <summary>
        /// On Create Event trigger from the file Create
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnCreated(object sender,FileSystemEventArgs e)
        {
            OpenConnection();
            _connection.InvokeAsync(Constants.SendMessage,
                   e.Name, Constants.FileCreated).Wait();          
        }
        /// <summary>
        /// On Change Event triggered from the File Change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnChanged(object sender, FileSystemEventArgs e)
        {
            OpenConnection();
            _connection.InvokeAsync(Constants.SendMessage,
                   e.Name, Constants.FileChanged).Wait();
            
        }
        /// <summary>
        /// On Renamed Event triggered from File Rename
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnRenamed(object sender, FileSystemEventArgs e)
        {
            OpenConnection();
            _connection.InvokeAsync(Constants.SendMessage,
                   e.Name, Constants.FileRenamed).Wait();
        }
        /// <summary>
        /// On Delete Event triggered from the File delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnDeleted(object sender, FileSystemEventArgs e)
        {
            OpenConnection();
            _connection.InvokeAsync(Constants.SendMessage,
                   e.Name, Constants.FileDeleted).Wait();           
        }
    }
}
