﻿using FileWatchInvoker.Common;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FileWatchInvoker
{
    /// <summary>
    /// Create Hub Server for the SingalR Event Emit
    /// </summary>
    public class FileInvokerHub : Hub
    {

        /// <summary>
        /// SignalR Message Sender to all the client registered to the ChatHub
        /// </summary>
        /// <param name="fileName">FileName Affected</param>
        /// <param name="message">Event Type</param>
        /// <returns></returns>
        public async Task SendMessage(string fileName, string message)
        {
            await Clients.All.SendAsync(Constants.RecieveMessage, fileName, message,System.DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));
        }
    }
}
