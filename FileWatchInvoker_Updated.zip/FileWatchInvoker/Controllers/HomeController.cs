﻿using FileWatchInvoker.Common;
using FileWatchInvoker.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FileWatchInvoker.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _config;
        private static string _filePath { get; set; }
        public HomeController(ILogger<HomeController> logger,IConfiguration config)
        {
            _logger = logger;
            _config = config;
            _filePath = _config.GetSection("AppSettings")["FilePath"];
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        /// <summary>
        /// Create File Method Creates New file from the input parameter
        /// </summary>
        /// <param name="fileName">File Name to Create</param>
        [HttpPost]
        public void CreateFile(string fileName)
        {            
            string FullPath = string.Format(@"{0}\{1}", _filePath, fileName);
            if (!System.IO.File.Exists(FullPath))
            {
                System.IO.File.Create(FullPath).Close();
                System.IO.File.AppendAllText(FullPath, System.DateTime.Now.ToString("dd/MMM/YYYY hh:mm:ss")+Environment.NewLine);
            }
        }

        /// <summary>
        /// Append Imput parameter message to the first file in the path
        /// </summary>
        /// <param name="message">Input message</param>
        [HttpPut]
        public void Append(string message)
        {
            DirectoryInfo dirInfo = new DirectoryInfo(_filePath);
            if (dirInfo.Exists && dirInfo.GetFiles().Any())
            {
                System.IO.File.AppendAllText(dirInfo.GetFiles().FirstOrDefault().FullName,message);
            }
        }

        /// <summary>
        /// Rename the First File in the Location
        /// </summary>
        /// <param name="fileName">New File Name</param>
        [HttpPut]
        public void Rename(string fileName)
        {
            DirectoryInfo dirInfo = new DirectoryInfo(_filePath);
            if (dirInfo.Exists && dirInfo.GetFiles().Any())
            {
                System.IO.File.Move(dirInfo.GetFiles().FirstOrDefault().FullName,string.Format(@"{0}\{1}", _filePath, fileName));
            }
        }
        /// <summary>
        /// Delete the fileName from the Location
        /// </summary>
        /// <param name="fileName">Input file Name</param>
        [HttpDelete]
        public void Delete(string fileName)
        {
            DirectoryInfo dirInfo = new DirectoryInfo(_filePath);
            if (dirInfo.Exists && dirInfo.GetFiles().Any())
            {
                System.IO.File.Delete(dirInfo.GetFiles().FirstOrDefault().FullName);
            }
        }
    }
}
