﻿"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").build();

//Disable send button until connection is established
//document.getElementById("sendButton").disabled = true;

connection.on("ReceiveMessage", function (FileName, message,timeInvoked) {
    var msg = message.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    var encodedMsg = "FileName : " + FileName + "<br/> Event Type => " + msg + "<br/> Date : " + timeInvoked;
    var li = document.createElement("li");
    li.innerHTML = encodedMsg;
    document.getElementById("messagesList").appendChild(li);
});
connection.start();
document.getElementById("btnRename").addEventListener("click", function (event) {
    var message = document.getElementById("messageInput").value;
    ajaxCall("/Home/Rename", { "fileName": message },"PUT", function () { console.log("File Renamed") });
    event.preventDefault();
});

document.getElementById("btnAppend").addEventListener("click", function (event) {
    var message = document.getElementById("messageInput").value;
    ajaxCall("/Home/Append", { "message": message },"PUT", function () { console.log("Message Appended to File") });
    event.preventDefault();
});


document.getElementById("btnCreate").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var message = document.getElementById("messageInput").value; 
    ajaxCall("/Home/CreateFile", { "fileName": message },"POST", function () { console.log("File Created") });
    event.preventDefault();
});

document.getElementById("btnDelete").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var message = document.getElementById("messageInput").value;
    ajaxCall("/Home/Delete", { "fileName": message }, "DELETE",function () { console.log("File Deleted") });
    event.preventDefault();
});

function ajaxCall(url, data, reqType, callBack) {
    $.ajax({
        url: url,
        type: reqType == undefined || reqType == "" ? "GET" : reqType,
        data: data,
        success: callBack(),
        error: function (err) { console.log(err) },
        dataType: "json"
    });
}